editArea.add_lang("ru",{
charmap_but: "Визуальная клавиатура",
charmap_title: "Визуальная клавиатура",
charmap_choose_block: "выбрать языковой блок",
charmap_insert:"вставить этот символ"
});
