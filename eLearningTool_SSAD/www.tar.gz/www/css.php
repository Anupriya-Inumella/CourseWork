
		<style>
		body
		{
			background-color:#A9A9A9;
			color:#00008B;
		}
		</style>
