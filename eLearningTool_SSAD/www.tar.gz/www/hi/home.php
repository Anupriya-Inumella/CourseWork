<?php include('../check_login.php');include('../css.php');?>
<html>
	<body>
		<a href="/logout.php">&#2354;&#2377;&#2327;&#2310;&#2313;&#2335;</a><br>
		<a href="/hi/student_home.php">&#2331;&#2366;&#2340;&#2381;&#2352;</a><br>
		<a href="/hi/teacher_home.php">&#2358;&#2367;&#2325;&#2381;&#2359;&#2325;</a><br>
		<a href="/home.php">English</a>
	</body>
</html>