<?php
if (!isset($_COOKIE["user_id"]))
{
	header("location:/index.php");
}
?>
