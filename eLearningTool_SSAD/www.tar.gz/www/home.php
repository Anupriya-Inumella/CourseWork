<?php include ('check_login.php'); include('css.php');?>
<html>
	<head>
	</head>	
	<body>
		<a href="/logout.php">logout</a><br>
		<a href="/student_home.php">Student</a><br>
		<a href="/teacher_home.php">Teacher</a><br>
		<a href="/hi/home.php">&#2361;&#2367;&#2306;&#2342;&#2368;</a>
	</body>
</html>
